let signup = document.querySelector(".signup");
let login = document.querySelector(".login");
let slider = document.querySelector(".slider");
let formSection = document.querySelector(".form-section");

signup.addEventListener("click", () => {
	slider.classList.add("moveslider");
	formSection.classList.add("form-section-move");
});

login.addEventListener("click", () => {
	slider.classList.remove("moveslider");
	formSection.classList.remove("form-section-move");
});

document.querySelector(".login-box .clkbtn").addEventListener("click", function() {
    var email = document.querySelector(".email.ele").value;
    var password = document.querySelector(".password.ele").value;
    
    var expectedEmail = "nitish454@gmail.com";
    var expectedPassword = "Nitish@123";

    if (email === expectedEmail && password === expectedPassword) {
        window.location.href = "login.html";
    } else {
        alert("Invalid username or password. Please try again.");
    }
});

