#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <WiFi.h>
#include <ArduinoBearSSL.h>
#include <PubSubClient.h> // Include the PubSubClient library

const char* ssid = "OM PG";
const char* password = "07112010";

const char* endpoint = "a1sodmotnq4zji-ats.iot.ap-south-1.amazonaws.com";
const int port = 8883; // MQTT port for secure connection

const char certificate[] PROGMEM = R"(
-----BEGIN CERTIFICATE-----
MIIDWjCCAkKgAwIBAgIVAJ4niFGwCL4j/L1x8Z5Sxh+oYHuGMA0GCSqGSIb3DQEB
CwUAME0xSzBJBgNVBAsMQkFtYXpvbiBXZWIgU2VydmljZXMgTz1BbWF6b24uY29t
IEluYy4gTD1TZWF0dGxlIFNUPVdhc2hpbmd0b24gQz1VUzAeFw0yMzA4MjAwNjA0
NDJaFw00OTEyMzEyMzU5NTlaMB4xHDAaBgNVBAMME0FXUyBJb1QgQ2VydGlmaWNh
dGUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDU2Izbz+4E40LLNdaQ
eMSp4pfYyF4qXKz8SgPMYhKri59rGO/XWw6kmFOqSL8Jn3U7mLMQz6EW+fRGUP1j
sHoEOYEFHpNRLCqBLi4a08xymqfHhasa5EYQbfxojE64c1B4MxrGjTTmjt/nQbyX
gtwODDYW9/Qh1m6sZaHc67PtS4o585JOPJwkrIuU+3rxsSIPC5t0rVoDhk4DD/tt
Tk4qRrqTQ2BVJRWe9xJtecMJ0Ebf4dkjf/qCmSJ3ypboHlch3lThlPTmyTDAJ5vW
2efXd1V817xMV4vQPtUnlT7/PBN071Zh5yozsBchIojlmm/gMbpLvnqLvRy6iDUU
r63vAgMBAAGjYDBeMB8GA1UdIwQYMBaAFNYNENDGBdnfF0/NPB+zQtmP6/ZUMB0G
A1UdDgQWBBToJeX069hesVLeuSFKVp9EUe2QnDAMBgNVHRMBAf8EAjAAMA4GA1Ud
DwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAQEAUHON5CgGRAGG2jpaVGGUaici
qkiuxlrucfgCZ8P6WgvVEAh5lJ9lzdU5D8SVZRAkOVeWQmglRy1C9GoHm07rJ25f
vDJmcvJw6W1wRtgpVUvXM7KNJ3Irnm02hLDEOCmEmYtJ5P1HfBWVHU182NheNqVk
x0CC7I7nnHcNszfUnARZH6SZcrhhGf2TnDda8TkXrrrVaw+tlLrm6ewJnWK7m8MD
6QNWFqNohtDkW6Xj8rDpPHb2i3PCWXPP98ZtfkRfvM77fJCIv/cmQixFTyza8l07
6PebtXyEPdlUAeeLLxzo/TBmPTjM8ulifOZ6/bNr6dP7A0IkE5ctAMmTx0z2xw==
-----END CERTIFICATE-----
)";

const char privateKey[] PROGMEM = R"(
-----BEGIN RSA PRIVATE KEY-----
MIIEogIBAAKCAQEA1NiM28/uBONCyzXWkHjEqeKX2MheKlys/EoDzGISq4ufaxjv
11sOpJhTqki/CZ91O5izEM+hFvn0RlD9Y7B6BDmBBR6TUSwqgS4uGtPMcpqnx4Wr
GuRGEG38aIxOuHNQeDMaxo005o7f50G8l4LcDgw2Fvf0IdZurGWh3Ouz7UuKOfOS
TjycJKyLlPt68bEiDwubdK1aA4ZOAw/7bU5OKka6k0NgVSUVnvcSbXnDCdBG3+HZ
I3/6gpkid8qW6B5XId5U4ZT05skwwCeb1tnn13dVfNe8TFeL0D7VJ5U+/zwTdO9W
YecqM7AXISKI5Zpv4DG6S756i70cuog1FK+t7wIDAQABAoIBABTdBTGmuBYSkMGK
jXWr4NsmMuw098X/P5WbS7QFCP93uDCvSRM7AbxwkgLnDpLK5pro5OSI9ali5ubd
mXjkG5G+cT8nOBmE0sXG2Q4YJLo3HqsYFyWTqqqBnXRCDJVX+FNP7xf3T3AqIRhy
ASJ42UknOUYXF/8ZHdAYRj15fTGNQDnYdFMadSGNC6MmvFgQy+ec5B3xKEChgknY
ABnJsHb6gM1tQvq3SfE4Ys5XQAWYZfiBOBaQYKXUEnSUyEO4YvVyr434wFB06AlE
Uy8sD0hSxMFmSX6AvVqDD+WCeGQC/UNStWC/MBZSqwJa3axiYrPM8v77J6XnoaKy
XXNfIMECgYEA83RfWC2lGLbbhWyDyci0StCWmOZEHtniJqpL/R0LYPsEvnornduW
jwsmZ4jmwUx9wmSEXWGd9vl37zhtx5X218OK0s1M0BhE+smOQsQyfsxyEFuwdlEq
C/ZHJeZP+JN21/lwxWNYz1Kg0ANUHT95qS87ETlpUhq/tGeh6HsyIUUCgYEA39Bk
KRbB57FQ+gkhUO3N0X061sRly9QhpXWvgy8I0HcwdZC4vV/2RTPDHggyywfn5Qst
o53W4xbPQZFTXxTq+jHJldGjtX7tE+yK0wketGzP08muAyj/HnyKjrbQrSLyxUXv
tstdi2/GN+61O9uvUXGJCiZ9s2XcRSmdSYBw86MCgYBza+XUKXfPesoivKrSnOwV
WEU94lXDhqs4h56VNxLw/LFoGQXaxoPf93pStc4pMLmi0wMKPsCkmeupp8gsSsYH
z3ZesOTM9+SkPbDLqLcD9KvTY5UK0zorB6z9o+6gPFGo3WMAwjQVvuftFtbnMvPc
KT9I0D5Fpdbjkgpp7RZ8PQKBgBd7acbV2GpStEhHhPNUv+9m0DGQUY3dJ9qQSmXd
HXOhzbfIA1n7I3+HOsV/3rRmk/H4BkXQXadd0Ujz0md7blvptVi+sgps0rrwanBR
2KLdd8CkvFkgiAPO1Uq765D+xbHk8I2hMKNcitN7fBBXsEE/RD2IZE/aNA4dm58G
ltM5AoGAEuPXSb7uRx1oizSPJwdJVGwGmVG6SII7xscJAFodgE5sON7XcxlCIXwL
mAHjx0ARHHo/OsmKnGam1Ixq2Xqt4dYMSd8wSI4pPMUgEF3G3vAiloM0zrGHsN5k
F/BBL1+FcqMk/ycZp3H1d7rTKLPBYdFnMwVaHBCrNKoGspTDros=
-----END RSA PRIVATE KEY-----
)";

const char rootCA[] PROGMEM = R"(
-----BEGIN CERTIFICATE-----
MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF
ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6
b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL
MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv
b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj
ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM
9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw
IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6
VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L
93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm
jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC
AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA
A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI
U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs
N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv
o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU
5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy
rqXRfboQnoZsG4q5WTP468SQvvG5
-----END CERTIFICATE-----
)";

const char* mqttTopic = "sensor/data"; // Change this to your MQTT topic
const int irSensorPin = 2;
const int vibrationSensorPin = 34;
const int buzzerPin = 32;

unsigned int irCount = 0;
unsigned int vibrationCount = 0;
bool vibrationDetected = false;
unsigned long lastVibrationTime = 0;
const unsigned long vibrationInterval = 3000;

WiFiClientSecure wifiClient;
PubSubClient client(wifiClient); // Create a PubSubClient instance

Adafruit_SSD1306 display(128, 64, &Wire, -1);

void setup() {
  pinMode(irSensorPin, INPUT);
  pinMode(vibrationSensorPin, INPUT);
  pinMode(buzzerPin, OUTPUT);

  client.setServer(endpoint, port);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }
  Serial.println("Connected to WiFi");

  Serial.begin(115200);
  while (!Serial);

  Wire.begin(25, 26);  // SDA at GPIO 25, SCL at GPIO 26

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);  // Initialize with I2C address
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Sensor Counts");
  display.display();
}

void loop() {
  int irValue = digitalRead(irSensorPin);
  int vibrationValue = digitalRead(vibrationSensorPin);
  unsigned long currentTime = millis();

  if (irValue == LOW) {
    delay(100);  // Debounce time
    while (digitalRead(irSensorPin) == LOW) {
    }
    irCount++;
    updateDisplay(irCount, vibrationCount);
  }

  if (vibrationValue == HIGH && !vibrationDetected && (currentTime - lastVibrationTime >= vibrationInterval)) {
    vibrationCount++;
    vibrationDetected = true;
    lastVibrationTime = currentTime;
    updateDisplay(irCount, vibrationCount);
    digitalWrite(buzzerPin, HIGH); // Turn on the buzzer
    delay(50); // Buzzer on time
    digitalWrite(buzzerPin, LOW);  // Turn off the buzzer
    delay(200); // Debounce delay
  }

  if (vibrationValue == LOW) {
    vibrationDetected = false;
  }

  char message[100]; // Adjust buffer size based on your data
  snprintf(message, sizeof(message), "{\"irCount\": %d, \"vibrationCount\": %d}", irCount, vibrationCount);

  if (!client.connected()) {
    if (connectToMqtt()) {
      client.subscribe(mqttTopic); // Subscribe to the MQTT topic
    }
  }

  if (client.connected()) {
    client.publish(mqttTopic, message); // Publish the message to the MQTT topic
    client.loop(); // Handle MQTT communication
  }
}

bool connectToMqtt() {
  Serial.print("Connecting to MQTT...");
  if (client.connect("ArduinoClient")) { // Provide a client ID
    Serial.println("connected");
    return true;
  } else {
    Serial.print("failed, rc=");
    Serial.print(client.state());
    Serial.println(" retrying in 5 seconds");
    delay(5000);
    return false;
  }
}

void updateDisplay(unsigned int irSensorCount, unsigned int vibrationSensorCount) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.print("IR Count: ");
  display.println(irSensorCount);
  display.print("Vibration Count: ");
  display.println(vibrationSensorCount);
  display.display();
}
