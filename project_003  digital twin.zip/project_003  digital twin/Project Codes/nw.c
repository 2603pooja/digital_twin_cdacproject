#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <AWS_SDK_Arduino.h>  // AWS SDK for Arduino library

const char* ssid = "OM PG";
const char* password = "07112010";

char char* awsAccessKey[] = "AKIAW3QIKKQEXF3Y3AG3";
const char* awsSecretAccessKey = "J0GrG1Pz4bVLr9SeO9MNq/aScv4+NHvKjIoxS3g3";
const char* awsRegion = "ap-south-1";  // Change to your AWS region

AWSWebSocketClient client(awsAccessKey, awsSecretAccessKey, awsRegion);

const int irSensorPin = 2;
const int vibrationSensorPin = 34;
const int buzzerPin = 32;

unsigned int irCount = 0;
unsigned int vibrationCount = 0;
bool vibrationDetected = false;
unsigned long lastVibrationTime = 0;
const unsigned long vibrationInterval = 3000;

Adafruit_SSD1306 display(128, 64, &Wire, -1);

void setup() {
    pinMode(irSensorPin, INPUT);
    pinMode(vibrationSensorPin, INPUT);
    pinMode(buzzerPin, OUTPUT);

    WiFi.begin(ssid, password);
    while (WiFi.status() != WL_CONNECTED) {
        delay(1000);
        Serial.println("Connecting to WiFi...");
    }
    Serial.println("Connected to WiFi");

    Serial.begin(115200);
    while (!Serial);

    Wire.begin(25, 26);  // SDA at GPIO 25, SCL at GPIO 26

    display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);
    display.println("Sensor Counts");
    display.display();
}

void loop() {
    int irValue = digitalRead(irSensorPin);
    int vibrationValue = digitalRead(vibrationSensorPin);
    unsigned long currentTime = millis();

    if (irValue == LOW) {
        delay(100);  // Debounce time
        while (digitalRead(irSensorPin) == LOW) {
        }
        irCount++;
        updateDisplay(irCount, vibrationCount);
    }

    if (vibrationValue == HIGH && !vibrationDetected && (currentTime - lastVibrationTime >= vibrationInterval)) {
        vibrationCount++;
        vibrationDetected = true;
        lastVibrationTime = currentTime;
        updateDisplay(irCount, vibrationCount);
        digitalWrite(buzzerPin, HIGH); // Turn on the buzzer
        delay(50); // Buzzer on time
        digitalWrite(buzzerPin, LOW);  // Turn off the buzzer
        delay(200); // Debounce delay
    }

    if (vibrationValue == LOW) {
        vibrationDetected = false;
    }

    // Prepare the JSON payload for DynamoDB
    char message[100];
    snprintf(message, sizeof(message), "{\"irCount\": %d, \"vibrationCount\": %d}", irCount, vibrationCount);

    sendToDynamoDB(message);

    // ... Rest of your loop ...
}

void sendToDynamoDB(const char* payload) {
    // Initialize the AWS client
    client.connect();

    // Create a PutItem request
    Aws::DynamoDBv2::Model::PutItemRequest putItemRequest;
    putItemRequest.WithTableName("sensorData")
                  .WithItem({
                    {"DeviceId", Aws::DynamoDBv2::Model::AttributeValue(payload)},
                    // Add other attributes as needed
                  });

    // Send the PutItem request
    auto outcome = client.PutItem(putItemRequest);
    if (outcome.IsSuccess()) {
        Serial.println("Data sent to DynamoDB successfully");
    } else {
        Serial.print("Failed to send data to DynamoDB: ");
        Serial.println(outcome.GetError().GetMessage());
    }

    // Disconnect the AWS client
    client.disconnect();
}

void updateDisplay(unsigned int irSensorCount, unsigned int vibrationSensorCount) {
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);
    display.print("IR Count: ");
    display.println(irSensorCount);
    display.print("Vibration Count: ");
    display.println(vibrationSensorCount);
    display.display();
}
