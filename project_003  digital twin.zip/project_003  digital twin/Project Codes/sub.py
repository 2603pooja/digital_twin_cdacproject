import paho.mqtt.client as mqtt

# Define the MQTT broker details
broker_address = "localhost"
broker_port = 1883

# Callback when the client receives a CONNACK response from the broker
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
    client.subscribe("my_topic")

# Callback when a message is received from the broker
def on_message(client, userdata, message):
    print("Received message: "+str(message.payload.decode("utf-8")))

# Create a MQTT client
client = mqtt.Client("Subscriber")

# Attach the callback functions
client.on_connect = on_connect
client.on_message = on_message

# Connect to the broker
client.connect(broker_address, broker_port)

# Start the loop to process incoming messages
client.loop_forever()
