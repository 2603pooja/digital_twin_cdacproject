import paho.mqtt.client as mqtt
import time

# Define the MQTT broker details
broker_address = "localhost"
broker_port = 1883

# Create a MQTT client
client = mqtt.Client("Publisher")

# Connect to the broker
client.connect(broker_address, broker_port)

# Publish a message
message = "Hello from Windows PC!"
topic = "my_topic"
client.publish(topic, message)

# Disconnect from the broker
client.disconnect()

print("Message published.")