#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <WiFi.h>
#include <ArduinoBearSSL.h>
#include <PubSubClient.h> // Include the PubSubClient library

#include "secrets.h"

const char* mqttTopic = "sensor/data"; // Change this to your MQTT topic
const int irSensorPin = 2;
const int vibrationSensorPin = 34;
const int buzzerPin = 32;

unsigned int irCount = 0;
unsigned int vibrationCount = 0;
bool vibrationDetected = false;
unsigned long lastVibrationTime = 0;
const unsigned long vibrationInterval = 3000;

WiFiClientSecure wifiClient;
PubSubClient client(wifiClient); // Create a PubSubClient instance

Adafruit_SSD1306 display(128, 64, &Wire, -1);

void setup() {
  pinMode(irSensorPin, INPUT);
  pinMode(vibrationSensorPin, INPUT);
  pinMode(buzzerPin, OUTPUT);

  client.setServer(endpoint, port);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }
  Serial.println("Connected to WiFi");

  Serial.begin(115200);
  while (!Serial);

  Wire.begin(25, 26);  // SDA at GPIO 25, SCL at GPIO 26

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);  // Initialize with I2C address
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Sensor Counts");
  display.display();
}

void loop() {
  int irValue = digitalRead(irSensorPin);
  int vibrationValue = digitalRead(vibrationSensorPin);
  unsigned long currentTime = millis();

  if (irValue == LOW) {
    delay(100);  // Debounce time
    while (digitalRead(irSensorPin) == LOW) {
    }
    irCount++;
    updateDisplay(irCount, vibrationCount);
  }

  if (vibrationValue == HIGH && !vibrationDetected && (currentTime - lastVibrationTime >= vibrationInterval)) {
    vibrationCount++;
    vibrationDetected = true;
    lastVibrationTime = currentTime;
    updateDisplay(irCount, vibrationCount);
    digitalWrite(buzzerPin, HIGH); // Turn on the buzzer
    delay(50); // Buzzer on time
    digitalWrite(buzzerPin, LOW);  // Turn off the buzzer
    delay(200); // Debounce delay
  }

  if (vibrationValue == LOW) {
    vibrationDetected = false;
  }

  char message[100]; // Adjust buffer size based on your data
  snprintf(message, sizeof(message), "{\"irCount\": %d, \"vibrationCount\": %d}", irCount, vibrationCount);

  if (!client.connected()) {
    if (connectToMqtt()) {
      client.subscribe(mqttTopic); // Subscribe to the MQTT topic
    }
  }

  if (client.connected()) {
    client.publish(mqttTopic, message); // Publish the message to the MQTT topic
    client.loop(); // Handle MQTT communication
  }
}

bool connectToMqtt() {
  Serial.print("Connecting to MQTT...");
  if (client.connect("ArduinoClient")) { // Provide a client ID
    Serial.println("connected");
    return true;
  } else {
    Serial.print("failed, rc=");
    Serial.print(client.state());
    Serial.println(" retrying in 5 seconds");
    delay(5000);
    return false;
  }
}

void updateDisplay(unsigned int irSensorCount, unsigned int vibrationSensorCount) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.print("IR Count: ");
  display.println(irSensorCount);
  display.print("Vibration Count: ");
  display.println(vibrationSensorCount);
  display.display();
}
