import paho.mqtt.publish as publish

broker_address = "192.168.77.85"  # Replace with Laptop 2's IP address
port = 1883

publish.single("topic/publish", "Hello from Laptop 1!", hostname=broker_address, port=port)
print("Message published!")
