#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

Adafruit_SSD1306 display(128, 64, &Wire, -1);

const int irSensorPin = 2;  // Pin connected to the IR sensor output

unsigned int irCount = 0;

void setup() {
  pinMode(irSensorPin, INPUT);

  Serial.begin(115200);
  while (!Serial);

  Wire.begin(25, 26);  // SDA at GPIO 25, SCL at GPIO 26

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);  // Initialize with I2C address
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("IR Sensor Count");
  display.display();
}

void loop() {
  int irValue = digitalRead(irSensorPin);

  if (irValue == LOW) {
    // Object detected
    delay(100);  // Debounce time
    while (digitalRead(irSensorPin) == LOW) {
      // Wait until object is removed
    }
    irCount++;
    updateDisplay(irCount);
  }
}

void updateDisplay(unsigned int count) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.print("IR Count: ");
  display.println(count);
  display.display();
}
