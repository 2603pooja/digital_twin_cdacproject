#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>


#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64


#define OLED_RESET    -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);


const int vibrationPin = 34; // Analog input pin connected to A0 of SW-420 sensor
unsigned int vibrationCount = 0;
bool vibrationDetected = false; // Flag to track if vibration has been detected
unsigned long lastVibrationTime = 0;
const unsigned long vibrationInterval = 3500; // 10 seconds


void setup() {
  pinMode(vibrationPin, INPUT);


  Serial.begin(115200);


  Wire.begin(25, 26);  // SDA at D4, SCL at D5
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);  // Initialize with I2C address


  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Vibration Sensor");
  display.display();
}


void loop() {
  int vibrationValue = analogRead(vibrationPin);
  unsigned long currentTime = millis();


  if (vibrationValue > 500 && !vibrationDetected && (currentTime - lastVibrationTime >= vibrationInterval)) {
    vibrationCount++;
    vibrationDetected = true;
    lastVibrationTime = currentTime;


    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);
    display.print("Vibrations: ");
    display.print(vibrationCount);
    display.display();


    delay(200); // Debounce delay
  }


  if (vibrationValue <= 500 && vibrationDetected) {
    vibrationDetected = false;
  }
}
