// Make API requests to retrieve data from Firebase for each gauge/chart
fetch('/get_data')
    .then(response => response.json())
    .then(data => {
        updateGauge(data.vibrationValue, 'gaugeContainer1');
        updateChart(data.irValues, 'chartCanvas1');
        
        // Repeat the process for the other gauges/charts
        // updateGauge(data.anotherValue, 'gaugeContainer2');
        // updateChart(data.anotherValues, 'chartCanvas2');
        // updateGauge(data.yetAnotherValue, 'gaugeContainer3');
        // updateChart(data.yetAnotherValues, 'chartCanvas3');
    });

function updateGauge(value, containerId) {
    const gauge = new JustGage({
        id: containerId,
        value: value,
        min: 0,
        max: 100,
        title: 'Vibration Value'
    });
}

function updateChart(values, containerId) {
    const ctx = document.getElementById(containerId).getContext('2d');
    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'IR Values',
                    data: values,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    fill: false
                }
            ]
        }
    });
}
