const express = require('express');
const app = express();
const firebase = require('firebase-admin');
const serviceAccount = require('C:\\Users\\admin\\Desktop\\login\\serviceAccountKey.json');

// Initialize Firebase
firebase.initializeApp({
  credential: firebase.credential.cert(serviceAccount),
  databaseURL: 'https://windmillprojectdata-default-rtdb.asia-southeast1.firebasedatabase.app/'
});

// Define a route to retrieve data from Firebase
app.get('/get_data', (req, res) => {
  const db = firebase.database();
  const ref = db.ref('sensorData'); // Change this to your Firebase path
  ref.once('value', snapshot => {
    const data = snapshot.val();
    // Process data as needed before sending it to the client
    res.json(data);
  });
});

// Serve the static HTML file
app.use(express.static(__dirname));
// Start the server
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
