<?php
$servername = $_GET['localhost']; // MySQL server address
$username = $_GET['root']; // MySQL username
$password = $_GET['nitish1998']; // MySQL password
$database = $_GET['arduino_data']; // MySQL database name
$table = $_GET['sensor_data'];       // MySQL table name
$port = $_GET['3308'];

$temperature = $_GET['temperature']; // Temperature value from ESP32
$humidity = $_GET['humidity'];       // Humidity value from ESP32

// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert data into table
$sql = "INSERT INTO $table (temperature, humidity) VALUES ($temperature, $humidity)";

if ($conn->query($sql) === TRUE) {
    echo "Data inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
